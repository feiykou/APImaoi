<?php

return [
    'img_prefix' => 'https://yue.mgoi.net',
    'token_expire_in'   =>   7200
];