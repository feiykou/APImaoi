<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/25
 * Time: 16:55
 */

return [
    'type' => [
        0 => '无导向',
        1 => '导向商品',
        2 => '导向主题'
    ]
];